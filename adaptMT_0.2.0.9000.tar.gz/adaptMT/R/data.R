#' Gene/Drug response dataset
#'
#' Microarray data of 22283 genes on breast cancer cells in response to estrogen
#'
"estrogen"
